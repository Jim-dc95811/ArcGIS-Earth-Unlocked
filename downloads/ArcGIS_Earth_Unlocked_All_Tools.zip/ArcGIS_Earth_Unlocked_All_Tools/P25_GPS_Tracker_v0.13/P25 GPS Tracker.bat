@echo off
title P25 GPS Tracker
cd /d "%~dp0"
where py >nul 2>nul && ( py "System Files\p25_tracker_app.py" & goto done )
where python >nul 2>nul && ( python "System Files\p25_tracker_app.py" & goto done )
echo.
echo   Python 3 was not found. Install it from https://www.python.org/downloads/
echo.
pause
:done
