@echo off
setlocal
cd /d "%~dp0"
title ArcGIS Earth PRAVE / ME Tracker
echo Starting Ready to Fly - on an older PC this first step can take a few minutes, please wait...
echo (Windows Defender may check the files first and slow the PC. That is normal - do not close this window.)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0System Files\Ready_To_Fly.ps1" -Folder "%~dp0System Files" -Tool "PRAVE / ME Tracker" -Packages "pyserial" -Imports "serial" -NeedEarth -NeedApi
if errorlevel 1 goto rtf_stopped
set "PYEXE="
set /p PYEXE=<"%~dp0System Files\python_path.txt"
if not defined PYEXE goto rtf_stopped
"%PYEXE%" "System Files\PRAVE_ME_Tracker.py"

set EXITCODE=%errorlevel%
echo.
echo PRAVE / ME Tracker exited with code %EXITCODE%.
pause
exit /b 0

:rtf_stopped
echo.
echo PRAVE / ME Tracker did not start - read the message above.
echo A log is in System Files\Ready_To_Fly_log.txt
pause
exit /b 1
