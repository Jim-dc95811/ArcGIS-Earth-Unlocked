@echo off
setlocal
cd /d "%~dp0"
title PRAVE RMC Field Decoder Tester - Version 1.0 Gold
echo Starting Ready to Fly - on an older PC this first step can take a few minutes, please wait...
echo (Windows Defender may check the files first and slow the PC. That is normal - do not close this window.)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0System Files\Ready_To_Fly.ps1" -Folder "%~dp0System Files" -Tool "PRAVE RMC Field Decoder Tester" -Packages "pyserial" -Imports "serial"
if errorlevel 1 goto rtf_stopped
set "PYEXE="
set /p PYEXE=<"%~dp0System Files\python_path.txt"
if not defined PYEXE goto rtf_stopped
echo ============================================================
echo   PRAVE / RMC Field Decoder Tester - Version 1.0 Gold
echo ============================================================
echo.
echo COM port and baud rate are configured at the top of the
echo Python file. Press Ctrl+C to stop the live test stream.
echo.

"%PYEXE%" "System Files\PRAVE_RMC_Field_Decoder_Tester_v1_0_Gold.py"

echo.
echo ============================================================
echo Tester exited.
echo ============================================================
pause
exit /b 0

:rtf_stopped
echo.
echo PRAVE RMC Field Decoder Tester did not start - read the message above.
echo A log is in System Files\Ready_To_Fly_log.txt
pause
exit /b 1
