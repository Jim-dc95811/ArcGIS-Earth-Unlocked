@echo off
cd /d "%~dp0System Files"
title Flight Recorder 0.2 TEST
where py >nul 2>&1
if %errorlevel%==0 (
    py -3 flight_recorder.py
) else (
    python flight_recorder.py
)
pause
