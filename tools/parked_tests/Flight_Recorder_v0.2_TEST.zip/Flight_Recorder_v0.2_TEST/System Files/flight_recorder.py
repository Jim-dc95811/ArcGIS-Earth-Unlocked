"""Flight Recorder v0.1 TEST - the black box for EarthStick flights.

Records what the ArcGIS Earth camera does (position, height, heading, tilt,
roll) and what the joystick is doing, 20 times a second, to a CSV file in
'Flight Logs' beside Record_Flight.bat. Fly normally with EarthStick (or the
mouse); the recorder only reads, it never moves the camera.

Purpose: the logs teach the autopilot / screen saver exactly how a real pilot
flies - speeds, turn rates, climb rates, how smooth a good approach is.
Stop with Ctrl+C or by closing the window; every line is saved as it goes.

0.2: Control lessons - the recorder calls out one control at a time
(twist right, twist left, hat up, hat down, climb, descend, forward, back,
slide left, slide right) and labels every line with the lesson, so each
control's effect on the camera can be measured on its own.
"""
import csv, datetime, math, os, sys, time
from pathlib import Path

VERSION = "0.2 TEST"
RATE_HZ = 20.0

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import EarthStick as ES  # same camera API and joystick reader as EarthStick 1.3.6

COLUMNS = ["t_s", "lesson", "clock", "lon", "lat", "alt_m", "heading", "tilt", "roll",
           "api_ms", "ground_mps", "climb_mps", "turn_dps",
           "stick_strafe", "stick_forward", "stick_yaw", "throttle", "hat_tilt", "buttons"]


def ground_m(lon1, lat1, lon2, lat2):
    p = math.radians((lat1 + lat2) / 2)
    dx = math.radians(lon2 - lon1) * math.cos(p) * ES.EARTH_RADIUS_M
    dy = math.radians(lat2 - lat1) * ES.EARTH_RADIUS_M
    return math.hypot(dx, dy)


HOLD_S = 5.0     # hold each control this long
SETTLE_S = 4.0   # hands off afterwards (shows how the camera coasts and stops)
LESSONS = [
    ("twist_right", "TWIST the stick RIGHT all the way (turn right)"),
    ("twist_left", "TWIST the stick LEFT all the way (turn left)"),
    ("hat_up", "HOLD the hat UP (pan / tilt up)"),
    ("hat_down", "HOLD the hat DOWN (pan / tilt down)"),
    ("button3_climb", "HOLD BUTTON 3 (climb / zoom out)"),
    ("button4_descend", "HOLD BUTTON 4 (descend / zoom in)"),
    ("stick_forward", "PUSH the stick FORWARD all the way"),
    ("stick_back", "PULL the stick BACK all the way"),
    ("stick_half_forward", "PUSH the stick HALF way forward"),
    ("slide_left", "PUSH the stick LEFT all the way (slide left)"),
    ("slide_right", "PUSH the stick RIGHT all the way (slide right)"),
]


def lesson_plan():
    """List of (start_s, end_s, label, call-out). Starts with 5 s of hands-off hover."""
    plan, t = [(0.0, 5.0, "hover", "Hands off - hovering (5 s). Leave the throttle where you like it.")], 5.0
    for i, (label, say) in enumerate(LESSONS, 1):
        plan.append((t, t + 3.0, "ready", f"[{i}/{len(LESSONS)}] Get ready: {say}  ... 3 2 1"))
        t += 3.0
        plan.append((t, t + HOLD_S, label, f"      GO! {label.replace('_', ' ')} ({HOLD_S:.0f} s)"))
        t += HOLD_S
        plan.append((t, t + SETTLE_S, label + "_letgo", "      LET GO - hands off"))
        t += SETTLE_S
    return plan


def open_stick():
    try:
        joy = ES.WinJoystick()
        print(f"Joystick: {joy.caps.szPname} - stick inputs are recorded too.")
        return joy
    except Exception as exc:
        print(f"No joystick ({exc}) - recording the camera only (mouse flights work too).")
        return None


def main():
    print(f"Flight Recorder {VERSION} - the black box for ArcGIS Earth flights")
    print("Only reads the camera; it never moves it. Ctrl+C or close the window to stop.\n")
    print("  1 = Free flight (fly however you like)")
    print("  2 = Control lessons (I call out one control at a time, about 2 1/2 minutes)")
    mode = (input("Choose 1 or 2 and press Enter: ").strip() or "1")[:1]
    plan = lesson_plan() if mode == "2" else None
    if plan:
        print("\nControl lessons: start at a safe height (a few thousand feet), level, hands off.")
        print("Watch this window - it tells you what to do and when.\n")
    logs = HERE.parent / "Flight Logs"
    logs.mkdir(exist_ok=True)
    joy = open_stick()

    print(f"Waiting for ArcGIS Earth Automation API at {ES.BASE_URL} ...")
    while True:
        try:
            ES.get_camera(); break
        except ES.EarthAPIError:
            time.sleep(1.0)

    name = datetime.datetime.now().strftime(("lessons" if plan else "flight") + "_%Y-%m-%d_%H%M%S.csv")
    path = logs / name
    print(f"Recording to Flight Logs\\{name}\n")
    period = 1.0 / RATE_HZ
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(COLUMNS)
        t0 = time.perf_counter(); nxt = t0; prev = None; n = 0; last_print = t0; misses = 0
        step = -1
        try:
            while True:
                nxt += period
                a = time.perf_counter()
                try:
                    cam = ES.get_camera()
                except ES.EarthAPIError:
                    misses += 1
                    time.sleep(0.5); nxt = time.perf_counter(); continue
                b = time.perf_counter()
                t = (a + b) / 2 - t0
                label = "free"
                if plan:
                    k = next((i for i, ph in enumerate(plan) if ph[0] <= t < ph[1]), None)
                    if k is None:
                        print("\n\nLessons complete - thank you, instructor.")
                        break
                    label = plan[k][2]
                    if k != step:
                        step = k
                        print("\n" + plan[k][3], end="", flush=True)
                p = cam["position"]
                lon, lat, alt = p["x"], p["y"], p["z"]
                hd = cam["heading"] % 360
                gs = cl = tr = ""
                if prev:
                    dt = t - prev[0]
                    if dt > 0:
                        gs = round(ground_m(prev[1], prev[2], lon, lat) / dt, 2)
                        cl = round((alt - prev[3]) / dt, 2)
                        tr = round(((hd - prev[4] + 540) % 360 - 180) / dt, 2)
                s = {}
                if joy:
                    try:
                        s = joy.read()
                    except Exception:
                        s = {}
                w.writerow([round(t, 3), label, datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3],
                            f"{lon:.7f}", f"{lat:.7f}", round(alt, 2), round(hd, 2),
                            round(cam["tilt"], 2), round(cam["roll"], 2), round((b - a) * 1000, 1),
                            gs, cl, tr,
                            round(s.get("strafe", 0), 3) if s else "", round(s.get("forward", 0), 3) if s else "",
                            round(s.get("yaw", 0), 3) if s else "", round(s.get("throttle", 0), 3) if s else "",
                            s.get("tilt", "") if s else "", s.get("buttons", "") if s else ""])
                prev = (t, lon, lat, alt, hd); n += 1
                if b - last_print >= 1.0:
                    fh.flush(); last_print = b
                if b - last_print < 0.001 and not plan:
                    mph = f"{gs * 2.23694:6.0f} mph" if gs != "" else "      - mph"
                    print(f"\r  {t:7.0f} s  {n:7,} samples  {alt * 3.28084:9,.0f} ft  "
                          f"{ES.compass_point(hd):>2} {hd:3.0f}  {mph}   ", end="", flush=True)
                time.sleep(max(0.0, nxt - time.perf_counter()))
        except KeyboardInterrupt:
            pass
    print(f"\n\nSaved {n:,} samples ({n / RATE_HZ / 60:.1f} min) to Flight Logs\\{name}")
    if misses:
        print(f"({misses} moments when ArcGIS Earth did not answer were skipped.)")
    print("Send me the CSV - it teaches the autopilot how you fly.")


if __name__ == "__main__":
    main()
